#pragma once

void initGLDebugOutput();