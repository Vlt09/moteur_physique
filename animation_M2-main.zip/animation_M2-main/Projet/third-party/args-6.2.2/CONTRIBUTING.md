* Use Allman style
* Don't use any non-standard-library libraries
* Keep everything in the args namespace
* Keep it simple and fast
* Your changes may be licensed how you wish as long as the project itself can
  remain MIT-licensed (essentially meaning your license for your changes must be
  either compatible with the MIT license or you must dual-license and the code
  put in here must be compatible with the MIT)
